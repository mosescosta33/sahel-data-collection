source('analysis/R/00_common.R')
e <- readRDS(file.path(outdir,'clean_events_private.rds'))
if(length(unique(e$civilian))!=2 || nrow(e)<50) stop('Need at least 50 events and both outcome classes.')
terms <- c('russian','jihadist')
terms <- terms[vapply(e[terms],function(x) length(unique(x))>1,logical(1))]
fit <- glm(as.formula(paste('civilian ~',paste(c(terms,'factor(country)'),collapse=' + '))),data=e,family=binomial())
if(!fit$converged || any(abs(coef(fit))>25)) stop('Check separation/unstable estimates.')
save_coefficients(fit,e,'civilian_logit',TRUE)
cat('Exponentiated coefficients are odds ratios.\n')
