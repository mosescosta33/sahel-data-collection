source('analysis/R/00_common.R')
needed(c('dplyr','tidyr','lubridate'))
suppressPackageStartupMessages(library(dplyr))
e <- read.csv(raw_path, stringsAsFactors=FALSE, check.names=FALSE)
names(e) <- tolower(gsub(' ','_',trimws(names(e))))
required <- c('event_id_cnty','event_date','country','event_type','actor1','actor2')
if (!all(required %in% names(e))) stop('Missing required ACLED fields; OSINT reports cannot substitute.')
for (x in c('admin1','assoc_actor_1','assoc_actor_2','civilian_targeting')) if(!x %in% names(e)) e[[x]] <- ''
for (x in c('fatalities','timestamp')) if(!x %in% names(e)) e[[x]] <- NA_real_
e$event_date <- as.Date(lubridate::parse_date_time(e$event_date,orders=c('ymd','dmy','mdy'),quiet=TRUE))
e <- e %>% filter(!is.na(event_date),event_id_cnty!='',country %in% cfg$countries) %>% arrange(desc(suppressWarnings(as.numeric(timestamp)))) %>% distinct(event_id_cnty,.keep_all=TRUE)
start <- as.Date(cfg$start_date); end <- if(is.null(cfg$end_date)) max(e$event_date,na.rm=TRUE) else as.Date(cfg$end_date)
e <- e %>% filter(!is.na(event_date),country %in% cfg$countries,event_date>=start,event_date<=end)
if(cfg$unit=='admin1_month') e <- e %>% filter(admin1!='')
if(!nrow(e)) stop('No usable events in the selected window.')
e$month <- format(e$event_date,'%Y-%m')
e$unit_id <- paste(e$country,e$admin1,sep='|')
if(cfg$unit=='country_month') e$unit_id <- e$country
if(!cfg$unit %in% c('admin1_month','country_month')) stop('Use Python engine for grid panels.')
actors <- apply(e[,c('actor1','actor2','assoc_actor_1','assoc_actor_2')],1,paste,collapse=' | ')
e$russian <- as.integer(grepl('wagner|africa corps|russian',actors,ignore.case=TRUE))
e$jihadist <- as.integer(grepl('jnim|jama.at nusrat|islamic state|is sahel|isgs|aqim|ansar dine|mujao',actors,ignore.case=TRUE))
e$civilian <- as.integer(e$event_type=='Violence against civilians' | tolower(e$civilian_targeting) %in% c('civilian targeting','1','true','yes'))
e$violent <- as.integer(e$event_type %in% c('Battles','Explosions/Remote violence','Violence against civilians'))
e$fatalities <- suppressWarnings(as.numeric(e$fatalities)); e$fatalities[e$fatalities<0 | e$fatalities%%1!=0] <- NA_real_
context <- e
selected <- e
if(!is.null(cfg$actor) && nzchar(cfg$actor)) selected <- selected[grepl(tolower(cfg$actor),tolower(actors),fixed=TRUE), ]
if(!is.null(cfg$event_types) && length(cfg$event_types)) selected <- selected[selected$event_type %in% cfg$event_types, ]
if(nrow(selected)==0) stop('Outcome filters retained no events.')
counts <- selected %>% group_by(unit_id,month) %>% summarise(total_events=n(),violent_events=sum(violent),civilian_events=sum(civilian),fatalities=if(any(is.na(fatalities))) NA_real_ else sum(fatalities),fatalities_missing=sum(is.na(fatalities)),.groups='drop')
activity <- context %>% group_by(unit_id,country,admin1,month) %>% summarise(russian_events=sum(russian),jihadist_events=sum(jihadist),context_fatalities=if(any(is.na(fatalities))) NA_real_ else sum(fatalities),context_fatalities_missing=sum(is.na(fatalities)),.groups='drop')
actor_counts <- context %>% group_by(unit_id,month) %>% group_modify(~{
  a <- trimws(unlist(strsplit(unlist(.x[,c('actor1','actor2','assoc_actor_1','assoc_actor_2')]),';',fixed=TRUE)))
  a <- a[!is.na(a)&a!=''&!grepl('civilian|protester',a,ignore.case=TRUE)]
  shares <- prop.table(table(a))
  data.frame(armed_actor_count=length(shares),actor_hhi=if(length(shares)) sum(shares^2) else NA_real_)
}) %>% ungroup()
universe <- context %>% distinct(unit_id,country,admin1)
if(cfg$unit=='country_month') universe <- universe %>% distinct(unit_id,country) %>% mutate(admin1='')
months <- format(seq(as.Date(format(start,'%Y-%m-01')),as.Date(format(end,'%Y-%m-01')),by='month'),'%Y-%m')
p <- if(isTRUE(cfg$coverage_confirmed)) tidyr::crossing(universe,month=months) else context %>% distinct(unit_id,month) %>% left_join(universe,by='unit_id')
activity <- activity %>% group_by(unit_id,month) %>% summarise(russian_events=sum(russian_events),jihadist_events=sum(jihadist_events),context_fatalities=if(any(is.na(context_fatalities))) NA_real_ else sum(context_fatalities),context_fatalities_missing=sum(context_fatalities_missing),.groups='drop')
p <- p %>% left_join(counts,by=c('unit_id','month')) %>% left_join(activity,by=c('unit_id','month')) %>% left_join(actor_counts,by=c('unit_id','month'))
for(x in c('total_events','violent_events','civilian_events','fatalities_missing','russian_events','jihadist_events','context_fatalities_missing','armed_actor_count')) p[[x]][is.na(p[[x]])] <- 0
p$fatalities[p$total_events==0] <- 0
p$context_fatalities[is.na(p$context_fatalities)&p$context_fatalities_missing==0] <- 0
p$civilian_rate <- ifelse(p$total_events>0,100*p$civilian_events/p$total_events,NA_real_)
p$complete_month <- as.Date(paste0(p$month,'-01'))>=start & as.Date(lubridate::ceiling_date(as.Date(paste0(p$month,'-01')),'month')-1)<=end
p$month_index <- match(p$month,months)-1
p <- p %>% arrange(unit_id,month) %>% group_by(unit_id) %>% mutate(previous_complete_month=lag(complete_month,default=FALSE),adjacent=month_index-lag(month_index)==1,russian_events_lag1=lag(russian_events),jihadist_events_lag1=lag(jihadist_events),armed_actor_count_lag1=lag(armed_actor_count),fatalities_lag1=lag(context_fatalities),civilian_events_lag1=lag(civilian_events),violent_events_lag1=lag(violent_events),total_events_lag1=lag(total_events),log1p_fatalities_lag1=log1p(lag(context_fatalities))) %>% ungroup()
for(x in names(p)[grepl('_lag1$',names(p))]) p[[x]][is.na(p$adjacent)|!p$adjacent] <- NA_real_
covfile <- Sys.getenv('COVARIATES_FILE','')
if(nzchar(covfile)) {
  extra <- read.csv(covfile,stringsAsFactors=FALSE)
  if(!'unit_id' %in% names(extra)) extra$unit_id <- if(cfg$unit=='country_month') extra$country else paste(extra$country,extra$admin1,sep='|')
  if(anyDuplicated(extra[c('unit_id','month')])) stop('Duplicate covariate keys.')
  extra <- extra[,setdiff(names(extra),c('country','admin1')),drop=FALSE]
  p <- left_join(p,extra,by=c('unit_id','month'))
}
write.csv(p,panel_path,row.names=FALSE)
saveRDS(selected,file.path(outdir,'clean_events_private.rds'))
cat(nrow(p),'panel rows; raw event file remains private.\n')
