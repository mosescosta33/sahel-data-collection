# Run from repository root: Rscript analysis/R/03_negative_binomial.R
needed <- function(packages) {
  absent <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(absent)) stop('Install required packages: ', paste(absent, collapse=', '))
}
needed(c('jsonlite'))
cfg <- jsonlite::fromJSON('config/research_lab.json', simplifyVector=TRUE)
outdir <- Sys.getenv('RESEARCH_OUTPUT', 'analysis/output')
dir.create(outdir, recursive=TRUE, showWarnings=FALSE)
raw_path <- Sys.getenv('ACLED_FILE', 'analysis/private/acled.csv')
panel_path <- file.path(outdir, 'panel.csv')
load_panel <- function() {
  if (!file.exists(panel_path)) stop('Run 01_clean_acled.R first.')
  d <- read.csv(panel_path, stringsAsFactors=FALSE)
  d$complete_month <- tolower(as.character(d$complete_month)) %in% c('true','1')
  d
}
covered <- function() {
  if (!isTRUE(cfg$coverage_confirmed)) stop('Confirm export coverage in config/research_lab.json before count/panel inference.')
}
model_data <- function() {
  covered()
  d <- load_panel()
  d <- d[d$complete_month, ]
  if(any(grepl('_lag1$',cfg$predictors)) && 'previous_complete_month' %in% names(d)) d <- d[tolower(as.character(d$previous_complete_month)) %in% c('true','1'), ]
  columns <- c(cfg$outcome, cfg$predictors)
  if (!all(columns %in% names(d))) stop('Missing specified variables.')
  d <- d[complete.cases(d[,columns, drop=FALSE]), ]
  if (nrow(d)<30) stop('Need at least 30 complete observations.')
  d
}
model_formula <- function(d, outcome=cfg$outcome) {
  predictors <- cfg$predictors[vapply(d[cfg$predictors], function(x) length(unique(x))>1, logical(1))]
  terms <- predictors
  if (cfg$fixed_effects %in% c('country','country_month')) terms <- c(terms,'factor(country)')
  if (cfg$fixed_effects %in% c('unit','unit_month')) terms <- c(terms,'factor(unit_id)')
  if (cfg$fixed_effects %in% c('country_month','unit_month','month')) terms <- c(terms,'factor(month)')
  if (isTRUE(cfg$population_offset)) {
    if (!'population' %in% names(d) || any(!is.finite(d$population) | d$population<=0)) stop('Positive matched population is required.')
    terms <- c(terms,'offset(log(population))')
  }
  as.formula(paste(outcome,'~',paste(if(length(terms)) terms else '1',collapse=' + ')))
}
save_coefficients <- function(fit, d, name, exponentiate=FALSE) {
  needed(c('sandwich','lmtest'))
  vc <- if(length(unique(d$unit_id))>1) sandwich::vcovCL(fit, cluster=d$unit_id, type='HC1') else sandwich::vcovHC(fit,type='HC1')
  table <- lmtest::coeftest(fit,vcov.=vc)
  result <- data.frame(term=rownames(table), coefficient=table[,1], standard_error=table[,2], p_value=table[,4], row.names=NULL)
  result$ci_low <- result$coefficient-1.96*result$standard_error
  result$ci_high <- result$coefficient+1.96*result$standard_error
  if(exponentiate) {
    result$ratio <- exp(result$coefficient); result$ratio_low <- exp(result$ci_low); result$ratio_high <- exp(result$ci_high)
  }
  write.csv(result,file.path(outdir,paste0(name,'_coefficients.csv')),row.names=FALSE)
  jsonlite::write_json(list(n=nobs(fit), formula=deparse(formula(fit)), aic=AIC(fit), software=R.version.string, packages=as.list(vapply(loadedNamespaces(), function(x) as.character(utils::packageVersion(x)), character(1))), interpretation='Conditional association; do not infer causality.'),file.path(outdir,paste0(name,'_metadata.json')),auto_unbox=TRUE,pretty=TRUE)
  print(result)
}
