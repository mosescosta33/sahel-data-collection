source('analysis/R/00_common.R')
needed(c('MASS','sandwich','lmtest'))
d <- model_data()
rows <- list()
for(fe in c('country_month','unit_month','country')) {
  cfg$fixed_effects <- fe; f <- model_formula(d)
  for(kind in c('poisson','negative_binomial')) {
    fit <- tryCatch(if(kind=='poisson') glm(f,data=d,family=poisson()) else MASS::glm.nb(f,data=d,control=glm.control(maxit=300)),error=function(e)e)
    if(inherits(fit,'error')) { rows[[length(rows)+1]] <- data.frame(model=kind,fe=fe,status=conditionMessage(fit),n=NA,aic=NA,coefficient=NA); next }
    rows[[length(rows)+1]] <- data.frame(model=kind,fe=fe,status='ok',n=nobs(fit),aic=AIC(fit),coefficient=if('russian_events_lag1' %in% names(coef(fit))) coef(fit)['russian_events_lag1'] else NA)
  }
}
write.csv(do.call(rbind,rows),file.path(outdir,'robustness.csv'),row.names=FALSE)
cat('Report all specifications, not only significant ones.\n')
