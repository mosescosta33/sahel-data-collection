source('analysis/R/00_common.R')
needed(c('sf','spdep','dplyr'))
e <- readRDS(file.path(outdir,'clean_events_private.rds'))
e$latitude <- suppressWarnings(as.numeric(e$latitude)); e$longitude <- suppressWarnings(as.numeric(e$longitude)); e$geo_precision <- suppressWarnings(as.numeric(e$geo_precision))
e <- e[complete.cases(e[,c('latitude','longitude','geo_precision')]) & e$geo_precision<=cfg$max_geo_precision,]
cell <- cfg$grid_degrees
e$grid_lat <- floor(e$latitude/cell)*cell+cell/2; e$grid_lon <- floor(e$longitude/cell)*cell+cell/2
g <- dplyr::count(e,country,grid_lat,grid_lon,name='events')
if(nrow(g)<5 || var(g$events)==0) stop('Need five cells and varying counts.')
coords <- as.matrix(g[,c('grid_lon','grid_lat')])
knn <- spdep::knearneigh(coords,k=min(4,nrow(g)-1),longlat=TRUE)
nb <- spdep::make.sym.nb(spdep::knn2nb(knn)); lw <- spdep::nb2listw(nb,style='W')
set.seed(cfg$seed); print(spdep::moran.mc(g$events,lw,nsim=199,alternative='two.sided'))
g$gi_star_z <- as.numeric(spdep::localG(g$events,spdep::nb2listw(spdep::include.self(nb),style='B')))
g$gi_p_normal <- 2*pnorm(-abs(g$gi_star_z)); g$gi_q_bh <- p.adjust(g$gi_p_normal,method='BH')
write.csv(g,file.path(outdir,'spatial_cells.csv'),row.names=FALSE)
cat('Conditional on observed occupied cells; degree grid is not PRIO-GRID.\n')
