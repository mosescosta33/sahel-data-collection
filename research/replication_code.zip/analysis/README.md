# Sahel Intel ACLED Research Lab

Author: Moses Costa. The Research Lab implements reproducible computational conflict analysis inside the existing Sahel Intel Quant Lab. OSINT candidate-event charts are a separate, labeled series below it.

## Use the website

1. Open Quant Lab and import your licensed ACLED CSV or JSON export. No Python installation is needed. The first analysis downloads the Pyodide scientific runtime from a pinned CDN version.
2. Set the countries and **actual export coverage dates**. Confirm coverage only when your account access tier and export support the complete period. Observed first/last event dates do not establish coverage.
3. Choose outcome, actor/event filter, unit and model. The flagship specification is Admin1-month civilian-targeting counts, lagged Russian/jihadist activity, actor-count and fatalities predictors, NB2 likelihood, country/calendar-month effects, and unit-clustered standard errors.
4. Inspect N, exclusions, convergence, uncertainty, dependence assumptions and substantive interpretation. Many models require more data or a defensible comparison design; the application explains these requirements instead of fabricating estimates.
5. Download the complete study ZIP: aggregate panel, exact configuration, machine-readable results, research report, and all R/Python source. Obtain the raw ACLED export separately through your own access.

Browser imports and analysis history are memory-only. They are not uploaded, sent to the collector, or saved in localStorage. Reloading clears them. Public scheduled output contains derived aggregates and estimates, not event IDs, notes, or event coordinates.

## Python replication

```bash
python -m pip install -r requirements-research.txt
python analysis/python/research_engine.py --events analysis/private/acled.csv --config config/research_lab.json --method negative_binomial --output analysis/output
```

Replace the example configuration with the configuration downloaded from your completed run. Optional `--covariates`, `--roster` and `--boundaries` take local CSV/JSON/GeoJSON files. Use `--method` with any method key in `research_engine.METHODS`. Browser and scheduled execution use copies of the **same** Python modules, verified during CI. CPython dependency versions match the pinned Pyodide distribution; platform differences can cause small numerical differences.

Raw files belong in ignored `analysis/private/` or `.cache/acled/`. Generated local results belong in ignored `analysis/output/`. Do not commit raw exports or credentials.

## Native R replication

Install the relevant packages for the scripts you run:

```r
install.packages(c('jsonlite','dplyr','tidyr','lubridate','ggplot2','MASS','sandwich','lmtest','fixest','sf','spdep'))
```

```bash
ACLED_FILE=analysis/private/acled.csv Rscript analysis/R/01_clean_acled.R
Rscript analysis/R/02_descriptive_statistics.R
Rscript analysis/R/03_negative_binomial.R
Rscript analysis/R/04_civilian_targeting_logit.R
Rscript analysis/R/05_panel_fixed_effects.R
Rscript analysis/R/06_event_study.R
Rscript analysis/R/07_spatial_analysis.R
Rscript analysis/R/08_robustness_checks.R
```

`09_bayesian_hierarchical.R` additionally needs `brms`, `posterior` and a working Stan compiler. It fits a hierarchical negative-binomial model with four MCMC chains. It is a more extensive sensitivity analysis than the browser's **hierarchical Poisson Laplace approximation**; these are different likelihoods/posterior algorithms and are labeled accordingly. Inspect R-hat, ESS, divergences and predictive checks. Native R scripts support country/Admin1 panels; use the shared Python engine for grid panels and all other methods. R scripts record package versions with results. None of the software automatically makes you proficient in its methods; the results must be explained and reviewed in substantive research.

## Variables and panel decisions

| Variable | Operationalization |
| --- | --- |
| `civilian_events` | Violence against civilians or explicit ACLED civilian-targeting flag, including flagged events of other types |
| `violent_events` | Battles, explosions/remote violence, violence against civilians |
| `russian_events` | Recorded Russian/Wagner/Africa Corps participation in primary or associated actors; participation proxy, not deployment footprint |
| `jihadist_events` | Recorded JNIM/Islamic State/AQIM/Ansar Dine/MUJAO actor-label matches; inspect actor taxonomy for the research question |
| `armed_actor_count` | Unique participating actor labels after excluding civilian/protester labels; a fragmentation proxy, not a verified armed-organization census |
| `actor_hhi` | Sum of squared shares in the same participation-label counts; undefined when there are no participating actors |
| `civilian_rate` | 100 × civilian-targeting events / selected events; undefined when denominator is zero |
| `fatalities` | Sum of reported fatalities; unknown if any contributing event lacks a usable number |
| `_lag1` predictors | Prior consecutive calendar month within the same unit; first observations and gaps stay missing |
| `complete_month` | Selected coverage includes the entire month; partial months are excluded from count/panel estimation |

Actor/event filters apply to outcome observations. Covariates are constructed from **all** selected country/date context events, preventing an outcome-only civilian filter from deleting the Russian activity covariate. Fatalities reported as zero stay zero; missingness is not recoded as zero. ACLED fatality estimates have their own measurement limits and generally do not identify exact civilian deaths.

Without a unit roster, the geographic universe consists of units with at least one recorded event in the export window. Upload a complete roster to include units with no recorded events. Zero-filling requires confirmed coverage. Country/Admin1 boundary changes are not automatically harmonized: use a stable research geography and a documented crosswalk. Degree grids are explicitly **not PRIO-GRID**, and occupied-cell-only spatial tests cannot establish population-wide risk.

Covariate join keys must be unique. Example:

```csv
unit_id,month,population,territorial_control_measure
Mali|Gao,2020-01,123456,0.4
```

These example values illustrate a schema only. Provide independently sourced values and documented measurement. Population exposure must be positive. No population, territorial control, intervention date or treatment status is fabricated from an article.

## Method coverage and limits

The engine implements descriptive statistics; Pearson/Spearman correlation; OLS, logit, Poisson, NB2, zero-inflated NB2 and Poisson hurdle models; fixed effects; common-date DiD/event study; baseline propensity matching and ATT weighting with overlap/balance checks; Moran I and Gi* with BH-adjusted normal-approximation p-values; KDE/nearest-neighbor/capital/border distances; cross-border screening; actor networks and HHI; recurrent-gap Cox survival; chronological Poisson-ridge/random-forest forecasting and event probability; hierarchical Poisson Laplace posterior; and specification sensitivity.

Frequentist estimates show coefficients, 95% intervals and p-values where identified. exp(β) means IRR in count models, odds ratio in logit, and hazard ratio in Cox. Bayesian output shows **approximate posterior credible intervals**, not frequentist p-values. Prior scale and posterior approximation are explicit. Count family selection is based on outcome distribution, scientific theory and diagnostics, not automatic significance hunting.

DiD and event studies require a user-chosen common treatment date and treated countries/unit IDs. Staggered adoption, time-varying treatment and instrumental-variable identification require a separate design. IV and regression discontinuity are research-design concepts, not automatically identified by conflict events. No coefficient is described as proving Russian deployments caused a change. Clustered covariance may be unreliable with few treatment/independent clusters, especially when treatment varies only by country.

Matching/weighting uses pre-treatment covariate means and penalized propensity scores. Scores are trimmed to [0.05,0.95]; matching uses a 0.2-SD logit-score caliper without replacement. Balance diagnostics and effective sample size are reported. Confidence intervals condition on estimated weights/matches and do not remove hidden confounding.

Forecast folds hold out entire future months. Models are evaluated against a last-month baseline; validation is also used for model selection and is not an independent final test. Only known lagged predictors enter next-month forecasts. Empirical error bands are not a guarantee of nominal coverage under temporal dependence. No forecast is published if coverage/history is inadequate.

## Scheduled ACLED collection

Configure repository secrets `ACLED_USERNAME` (or `ACLED_EMAIL`) and `ACLED_PASSWORD`, or `ACLED_ACCESS_TOKEN`. Account access/consent must permit the requested export. Credentials never enter the public site. The downloader uses current OAuth and **cursor-based pagination**. It refuses missing/repeated cursors and replaces a snapshot only after all requested countries complete. Full periodic snapshot replacement also reconciles deleted events and revisions. Requests are cached for 20 hours within the same query/date.

The private repository's Actions cache stores raw records; it is never copied into public dashboard output or debug artifacts. Publishing contains monthly aggregates, model outputs and source-only replication downloads. `coverage_confirmed` defaults to false: pagination completion is not evidence that the account's historical/recency access is complete. Change it only after checking account scope. Missing credentials produce an honest awaiting-data state; a failed refresh retains an explicitly stale prior aggregate snapshot.

## Verification

```bash
python -m unittest discover -s tests -p test_research_lab.py -v
python scripts/build_research_lab.py
python scripts/validate_research_lab.py
```

Tests use synthetic, clearly labeled fixtures to check known effects, chronology, missingness, revisions, joins and separation. Synthetic fixtures never populate the public dashboard. GitHub CI tests the scientific engine and browser module syntax separately from the collector so missing research credentials cannot break OSINT collection.

## Statistical concepts to be able to explain

- Mean/median describe center; variance/standard deviation describe dispersion. A count with variance much larger than its mean motivates inspecting a negative-binomial specification.
- Sampling distributions describe estimates across hypothetical replications. A 95% confidence interval is a procedure's long-run coverage statement, not a 95% probability that this realized fixed parameter lies inside it.
- Standard errors quantify estimator uncertainty conditional on assumptions. Clustering allows within-unit error dependence; enough independent clusters are still needed.
- A p-value is a tail probability under the specified null and model; it is not the probability the null is true. Many model comparisons raise multiple-testing and selection issues.
- OLS minimizes squared residuals. Logit models log odds; Poisson/NB model expected counts on the log scale. Maximum likelihood selects parameters that maximize the modeled probability of observed data.
- Fixed effects absorb invariant unit attributes or common time shocks. They do not remove all time-varying confounding. Interactions represent how an association differs across covariate values.
- Heteroskedasticity means error variance changes across observations. Multicollinearity makes separate effects difficult to estimate. Rank deficiency makes some parameters unidentified.
- Selection, omitted variables, measurement error and endogeneity can make an observed association differ from a causal effect. Matching, weighting and DiD add assumptions; they do not make those assumptions true.
- Event-study leads diagnose some patterns inconsistent with parallel trends; low power can hide violations. IV needs a defensible instrument/exclusion restriction. RD needs a genuine assignment threshold with continuity assumptions.
- Cross-validation for time-dependent prediction must respect chronology. In-sample fit is not evidence of future predictive accuracy. Robustness means examining defensible alternative measures/specifications and reporting their differences.
- Bayesian priors, likelihood and posterior are distinct. Laplace is an approximation; MCMC requires convergence diagnostics. Credible intervals have a posterior-probability interpretation conditional on the model and prior.

## Primary methodology and software references

- [ACLED codebook](https://acleddata.com/methodology/acled-codebook)
- [ACLED OAuth authentication](https://acleddata.com/api-documentation/getting-started)
- [ACLED cursor pagination](https://acleddata.com/api-documentation/elements-acleds-api)
- [statsmodels documentation](https://www.statsmodels.org/stable/index.html)
- [Pyodide pinned package distribution](https://pyodide.org/en/0.28.3/usage/packages-in-pyodide.html)
- [scikit-learn time-series validation](https://scikit-learn.org/stable/modules/cross_validation.html#time-series-split)
- [NetworkX centrality](https://networkx.org/documentation/stable/reference/algorithms/centrality.html)
- [fixest documentation](https://lrberge.github.io/fixest/)
- [brms documentation](https://paulbuerkner.com/brms/)
